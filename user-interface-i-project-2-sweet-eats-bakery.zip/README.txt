A Pen created at CodePen.io. You can find this one at https://codepen.io/wsong0121/pen/mgjaqx.

 